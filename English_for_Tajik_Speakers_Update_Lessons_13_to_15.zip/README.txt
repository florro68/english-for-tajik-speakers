LESSONS 13–15 GITHUB UPDATE
Upload all eight files to the existing repository root (not into a subfolder).
New: lesson13.html, lesson14.html, lesson15.html.
Updated: index.html and lesson12.html (Lesson 12 → Lesson 13).
Shared: script.js, styles.css. README.txt is informational.
Commit message: Add Lessons 13 to 15
After committing, refresh the live website and test Lessons 12–15, navigation and audio.
Audio is browser-generated English speech, not recorded MP3.
Tajik text should be reviewed by a fluent Tajik speaker before broad distribution.
